export const years = [
  {year: '1.5-yillik', month: 18},
  {year: '2-yillik', month: 24},
  {year: '3-yillik', month: 36},
  {year: '4-yillik', month: 48},
  {year: '5-yillik', month: 60},
  {year: '6-yillik', month: 72},
  {year: '7-yillik', month: 84},
];
export const months = [
  {year: '1.5-yillik', month: 18},
  {year: '2-yillik', month: 24},
  {year: '3-yillik', month: 36},
];
